<?php
session_start();
header('Content-Type: application/json');
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Não autenticado']);
    exit;
}
require('../../config/db.php');
$user_role = $_SESSION['user_role'] ?? '4';
$podeEditar = ($user_role === '2' || $user_role === '1');
if (!$podeEditar) {
    echo json_encode(['success' => false, 'message' => 'Sem permissões para eliminar']);
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Método inválido']);
    exit;
}
$id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
if ($id <= 0) {
    echo json_encode(['success' => false, 'message' => 'ID inválido']);
    exit;
}
try {
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
   
    // Verificar se a equipa existe
    $stmt = $conn->prepare("SELECT id FROM teams WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
   
    if ($result->num_rows === 0) {
        echo json_encode(['success' => false, 'message' => 'Equipa não encontrada']);
        exit;
    }
   
    // Eliminar a equipa
    $stmt = $conn->prepare("DELETE FROM teams WHERE id = ?");
    $stmt->bind_param("i", $id);
   
    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            echo json_encode([
                'success' => true,
                'message' => 'Equipa eliminada com sucesso'
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'message' => 'Nenhuma equipa foi eliminada'
            ]);
        }
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Erro ao eliminar equipa'
        ]);
    }
   
    $stmt->close();
   
} catch (Exception $e) {
    error_log('Erro ao eliminar equipa: ' . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Erro no servidor: ' . $e->getMessage()
    ]);
}
$conn->close();
?>